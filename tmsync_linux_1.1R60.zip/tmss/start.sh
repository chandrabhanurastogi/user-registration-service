#!/bin/sh

# Absolute path this script is in
SCRIPTPATH=$(dirname $0)
echo Starting TM Sync Server from $SCRIPTPATH directory

java -jar $SCRIPTPATH/tmSyncServer.jar $SCRIPTPATH/tm_sync_config.json
