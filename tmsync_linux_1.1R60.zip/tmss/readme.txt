the Time Machine Sync Server (TMSS) Readme
------------------------------------------

the Time Machine Sync Server (TMSS) software product provides a great set of features enabling the virtual time management and synchronization
for complex distributed applications across the network.

The TMSS enables customers to use the Time Machine features for application components deployed on different hosts across the network
in synchronized and consistent way. The TMSS acts as a single virtual time management, configuration and synchronization service
for complex applications which are comprised of different components like databases, application servers, hosts,
operating system users/groups, client applications, etc.

The TMSS provides the following key features:

*	Provides single virtual time management and configuration service across the network.
*	Support of virtual time synchronization for the different types of targets.
*	Provides the HTTP API for the consistent and automated virtual time synchronization for the complex testing scenarios and routines for the distributed applications.
*	Provides the intuitive Java based GUI Management Console for the TMSS sync group management and virtual time configuration.
*	Easy to install, configure and use.
*	Supports SSL protocol for the TMSS HTTP API.


SYSTEM REQUIREMENTS
-------------------

Time Machine
~~~~~~~~~~~~


The Time Machine (TM) must be installed on all target hosts before you can proceed to the TMSS installation. See readme.txt files delivered
with particular Time Machine Suite products installed on the target systems to learn what specific Time Machine version is required.

You must ensure that the Time Machine is successfully activated with the valid license codes and the Time Machine service runs without any issues.
Refer to the Time Machine User Manual for details about how to install and activate the Time Machine software on your operating system. 

To check if the Time Machine service is running on the target system, issue the following command under the root user for Unix/Linux platforms or under Administrator on Windows:

tmuser -l

If the output of this command returns any error message, contact Solution-Soft Systems technical support for assistance.
Execute the tmuser_setup program located in the TM installation folder to grant the TM execution privilege to the regular users.
When prompted choose the following option 1:

1) Setup the Time Machine so that the regular users can update its own virtual time.



Operating System
~~~~~~~~~~~~~~~~

the TMSS product supports the following operating systems which are supported by the Time Machine product:


*	AIX

*	HPUX Itanium

*	Linux

*	Solaris SPARC

*	Windows



Java Version
~~~~~~~~~~~~

The TMSS product supports the Java SE JDK or JRE version 1.8 or later.

You must install 64 bit version of Java for the following operating systems:

*	HP-UX Itanium


You can install either 32 bit or 64 bit version of Java for the following operating systems:

*	AIX
*	Solaris SPARC
*	Linux
*	Windows





Time Machine Suite Products Requirements
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The TMSS product supports the following versions of the Time Machine Suite products installed on the target systems:

* Time Machine version 10 or later.

* Time Machine Management Console R26 or later.

* Time Machine Framework for Oracle (TMFO) version 1.1 R11 or later

* Time Machine Framework for Oracle WebLogic (TMFWL) version 1.1 R25 or later

* Time Machine Framework for JBoss (TMFJB) version 1.1 R25 or later

* Time Machine Framework for IBM WebSphere (TMFWS) version 1.1 R36 or later



Network:
~~~~~~~~

The TMSS product must be installed on a host which has the network access to all hosts on which the targets to be synchronized are running.
Also, the additional ports must be open for the TMSS server to accept the incoming connections.
Please refer to the "Installation" section of this manual for further details about the network ports that must be open.



TMSS Server and Targets System Clock Synchronization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You must ensure that all systems where the TMSS server is running and all the target systems have the synchronized system clocks.
This requirement is necessary in order the TM Sync Server can synchronize virtual times between all the target systems.
Please refer to the Network Time Protocol (NTP) documentation http://www.ntp.org/documentation.html to learn how to synchronize the system clocks of the computers over the network.



SOFTWARE INSTALLATION
---------------------

Follow the below steps to perform the initial TMSS product installation and configuration.

For the complete installation instructions, please see the "Installation" section in the tm_sync_server_manual.pdf located in the product bundle.  



TMSS INSTALLATION
~~~~~~~~~~~~~~~~~


1. On the TMSS host, create a new operating system user which will own the TMSS installation. For example, create user called tmss.

2. Login to the TMSS host as the TMSS owner created in the step 1. Verify if Java version 1.8 or later is installed on the TMSS host and accessible through the PATH environment variable.
Ensure that the correct Java bit type (32 or 64 bit) is installed as described in the "System Requirements" section.

You can check the version of Java virtual machine by the command:

java -version

If the above command fails or Java version is not 1.8 or later, then install the Java JRE or JDK version 1.8 or later under the TMSS user.

3. Create a new directory owned by the TMSS user. This directory will be used as the installation and working directory of the TMSS product.

For example, on Unix/Linux platforms: 

$ mkdir /home/oracle/the TMSS

For example, on Windows platforms:   

C:\ mkdir C:\the TMSS



4. Copy the TMSS product distribution files to the directory created in the step 3.

5. Go to the TMSS installation folder and open the configuration file tm_sync_config.json in any text editor.
The default configuration file looks like the listing below:

{

  "port" : 4500,
  "http_port" : 4600,
  "http_threads" : 20,
  "tcptimeout" : 300,
  "oper_logging" : true,
  
}

You can configure the following TMSS parameters:

"port" - configures the network port on which the TMSS listens for the incoming TCP/IP connections. You can configure this parameter to any available port number within the allowed port range.
By default, this parameter is 4500;

"http_port" - configures the network port on which the TMSS server listens for the incoming HTTP requests.
This port is used by the TMSS HTTP API. By default, this port is 4600;

"http_threads" - configures the connection thread number for the HTTP API requests.
You might want to increase this parameter if a big number of simultaneous requests uses TMSS HTTP API.
By default, this parameter is 20;

"tcptimeout" - configures connection timeout in seconds which is used by TMSS server to connect to sync group targets. By default, tcptimeout is 300. 
You may adjust this parameter to decrease response time when some sync group targets are offline or not reachable because of network issues.

"oper_logging" - this parameter controls logging of all sync group operations to TMSS log file. By default, oper_logging is true.

You can configure the TMSS server to use the SSL protocol for higher level security. Please refer to TMSS manual for further details about how to configure SSL for TMSS API.


6. Open in any text editor the startup script for the TMSS server: start.sh on Linux/Unix platforms or start.cmd on Windows.
Verify that the startup script has the correct path to the Java home.

7. Start the TMSS server either with the startup script start.sh/start.cmd or with the command below:

$ java -jar tmSyncServer.jar tm_sync_config.json

You can use the start.sh or start.cmd sample startup scripts to start up the TMSS server.
For example, use the following command to start the TMSS server in background:

$ cd <the TMSS_Install_Dir>
$ nohup ./start.sh &


8. Check the output to verify that the TMSS is started.

9. To stop the TMSS server, simply stop the corresponding java process in the operating system. For example, you can use the following command on Linux to stop the TMSS server:

$ pkill -f tmSyncServer.jar



TMSS Licensing
~~~~~~~~~~~~~~

Use the following steps to obtain a license for the TMSS:

* Execute the program called sssliclumgr ( sssliclumgr.cmd in Windows ) in the TMSS installation folder with the �-k� option.

* Send the output to support@solution-soft.com to request a license or trial key

* After you receive your license or trial key, execute the sssliclumgr ( sssliclumgr.cmd in Windows ) program under root user on Linux/Unix system or Administrator user on Windows system,
  this time without any options and when prompted, paste or enter the license or trial key.

You must have a license or trial key applied before proceeding to start the Time Machine Sync Server.




INSTALLING TMSS As Windows Service
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


You can install the TMSS as a Windows service as described below:

* Open the install_sync_server_service.cmd Windows batch script and adjust the TMSS installation folder path if your TMSS installation folder is not C:\TMSS ;

* Launch the install_sync_server_service.cmd under Administrator user to install the TMSS as a Windows service;




TM MANAGEMENT CONSOLE INSTALLATION
----------------------------------


TM Management Console is a Java GUI application that provides an intuitive and convenient GUI interface for the TMSS sync group configuration
and management. TMConsole allows users to create and configure sync groups for complex distributed applications as well enable or disable sync groups for application targets.


System Requirements
~~~~~~~~~~~~~~~~~~~

See the TMConsole readme.txt file for details about the specific system requirements.


To install the TM Management Console, extract the distribution ZIP archive to a separate folder for which you have write and read
permissions. Please notice that the TMConsole will create files in its installation directory, so write permissions are required
for the operating system user under which the TMConsole will be started.



SOFTWARE REMOVAL
----------------


Time Machine SYNC SERVER REMOVAL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Use the steps below to completely remove the TMSS product from your system.

1. Login to the host as the TMSS user.

2. Stop the TMSS server component if it is running. To stop the TMSS simply stop the corresponding Java process in the operating system.
For example, you can use the following command on Linux to stop the TMSS server:

$ pkill -f tmSyncServer.jar.

3. Remove the TMSS installation folder from the file system.




TM MANAGEMENT CONSOLE REMOVAL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You can safely remove the directory in which the TMConsole is installed.



SOFTWARE UPGRADE
----------------


UPGRADE Time Machine SYNC SERVER
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Follow the steps described below to upgrade the TMSS to the latest version:

1. Stop the TMSS server if it is running. To stop the TMSS simply stop the corresponding Java process in the operating system.
   For example, you can use the following command on Linux to stop the TMSS server:

$ pkill -f tmSyncServer.jar

2. Extract the files from the latest the TMSS software archive to a staging directory.

3. Go to the staging directory and open the release_notes.txt file and check if there are specific actions which should be performed to complete the upgrade operation.
   This step is necessary only if the release_notes.txt file is provided in new version.
   
4. Execute upgrade.sh script in Unix and Linux operating systems or upgrade.cmd in Windows. For example, in Linux:

$ chmod +x upgrade.sh
$ sh ./upgrade.sh

  When prompted, provide full path to the folder where the TMSS server is installed. During its work, the upgrade script creates a backup of the TMSS installation folder
  and copies all the necessary files to the TMSS installation folder. 

5. Check for errors in upgrade script output. If you encounter any errors during upgrade procedure, please contact Solution-Soft Systems support.

6. Start the TMSS server.


IMPORTANT: Do not remove manually any files or directories from the TMSS installation directory because this might cause the software to function incorrectly.
You may only remove files from the TMSS installation directory if the release_notes.txt file has explicit instructions to remove specific files. 




UPGRADE TM MANAGEMENT CONSOLE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To upgrade TM Management Console to the latest version, extract the archive with the latest TM Management Console version to a stage directory.
Copy all files from the stage directory to the TM Console installation directory. You can safely replace all old files.
Check if TM Console distribution has the release_notes.txt file. Read the release_notes.txt file (if available) to learn the specific details
about the upgrade procedure for the particular TM Console version.

IMPORTANT: Do not remove manually any files from the TM Console installation directory because this might cause the software to function incorrectly.
You may only remove files from the TM Console installation directory if the release_notes.txt has explicit instructions to remove specific files.


the TMSS Product Information
------------------------

Solution-Soft Systems, Inc.		Web site:  http://www.solution-soft.com
Mission College Blvd., Suite 777	E-mail:    info@solution-soft.com
Santa Clara, CA 95054, USA
+1(408)346-1414

