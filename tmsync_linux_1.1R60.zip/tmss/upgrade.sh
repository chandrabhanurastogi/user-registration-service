#!/bin/sh

STAGEPATH="$(dirname $0)"

echo "Upgrading to Version"
cat "$STAGEPATH"/version.txt
echo =====================

# Prompt for the TMSS installation directory

echo -n "Enter TMSS installation directory (do NOT use double-quotes if the path contains spaces): "
read TMSS_DIR

echo "Provided TMSS installation directory: $TMSS_DIR"

# check if $TMSS_DIR not exists

if [ ! -d "$TMSS_DIR" ]; then
  echo "ERROR: Directory "$TMSS_DIR" does not exist. Exiting..."
  exit -1
fi

# check if tmSyncServer.jar is present in $TMSS_DIR directory

if [ ! -f "$TMSS_DIR/tmSyncServer.jar" ]; then
  echo "ERROR: "$TMSS_DIR" is not valid TMSS directory. Exiting..."
  exit -1
fi

# confirm upgrade operation

echo -n "Are you sure to start TMSS upgrade (y/n)?: "

read YES_NO
if [ "$YES_NO" != "y" ]
then
  echo "ERROR: Upgrade cancelled. Exiting..."
  exit -1
fi

# create backup directory

current_time=$(date "+%Y.%m.%d-%H.%M.%S")
TMSS_DIR_BACKUP="$TMSS_DIR"/tmss_backup.$current_time
echo "Backup directory is "$TMSS_DIR_BACKUP""
mkdir "$TMSS_DIR_BACKUP"

if [ ! -d "$TMSS_DIR_BACKUP" ]; then
  echo "ERROR: Unable to create backup directory "$TMSS_DIR_BACKUP". Exiting..."
  exit -1
fi

echo "Created backup directory "$TMSS_DIR_BACKUP" for the previous TMSS installation."

echo "Backing up the previous TMSS installation to "$TMSS_DIR_BACKUP""

find "$TMSS_DIR" -maxdepth 1 -type f -exec cp -r -t "$TMSS_DIR_BACKUP" {} +

if [ -d "$TMSS_DIR"/sync_groups ]; then
   cp -pr "$TMSS_DIR"/sync_groups "$TMSS_DIR_BACKUP"
fi

if [ -d "$TMSS_DIR"/scripts ]; then
   cp -pr "$TMSS_DIR"/scripts "$TMSS_DIR_BACKUP"
fi


# copy new files from the $STAGEPATH to $TMSS_DIR directory excluding *.json files

find "$STAGEPATH" -maxdepth 1 ! -name '*.json' -type f -exec cp -r -t "$TMSS_DIR" {} +
rm -rf "$TMSS_DIR"/upgrade.sh

echo "Upgrade completed successfully."
cat "$TMSS_DIR"/version.txt

exit 0
